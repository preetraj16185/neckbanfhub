// alert("welcome to NECKBAND");
// prompt("enter your name");

// let age=prompt("enter age");

// if(age<=14){
//     alert("Not allow");
// } else{
//     alert(" Allow");
// }

let n1=prompt("first number");
let n2=prompt("second number");

z= n1 / n2;
alert(z);
